/*
 * motor.h
 *
 *  Created on: Aug 22, 2017
 *      Author: Arvind
 */

#ifndef MOTOR_H_
#define MOTOR_H_

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif
/* Kernel includes. */
//#include "FreeRTOS.h"
//#include "task.h"
//#include "queue.h"
#include <stdio.h>
#include <stdbool.h>
#include "../inc/defines.h"


/* Priorities at which the tasks are created. */
#define 	configQUEUE_RECEIVE_TASK_PRIORITY	( tskIDLE_PRIORITY + 2 )
#define		configQUEUE_SEND_TASK_PRIORITY		( tskIDLE_PRIORITY + 1 )
#define 	configMOTOR_TASK_PRIORITY			( tskIDLE_PRIORITY + 2 )
/* The rate at which data is sent to the queue, specified in milliseconds. */
#define mainQUEUE_SEND_FREQUENCY_MS				( 500 / portTICK_RATE_MS )

/* The number of items the queue can hold.  This is 1 as the receive task
will remove items as they are added, meaning the send task should always find
the queue empty. */
#define mainQUEUE_LENGTH						( 1 )


#define SBIT_CNTEN     0
#define SBIT_PWMEN     2

#define SBIT_PWMMR0R   1

#define SBIT_LEN0      0
#define SBIT_LEN1      1
#define SBIT_LEN2      2
#define SBIT_LEN3      3
#define SBIT_LEN4      4


#define SBIT_PWMENA1   9
#define SBIT_PWMENA2   10
#define SBIT_PWMENA3   11
#define SBIT_PWMENA4   12


#define PWM_1          0 //P2_0 (0-1 Bits of PINSEL4)
#define PWM_2          2 //P2_1 (2-3 Bits of PINSEL4)
#define PWM_3          4 //P2_2 (4-5 Bits of PINSEL4)
#define PWM_4          6 //P2_3 (6-7 Bits of PINSEL4)

/********************************** Motor 0 Control Definitions ****************************************/

#define RIGHTMOTOR_ENABLE_BIT 		3
#define RIGHTMOTOR_BREAK_BIT 		1
#define RIGHTMOTOR_DIR_BIT 			2
#define RIGHTMOTOR_HALLIN_BIT 		4
#define RIGHTMOTOR_PWM_ENABLE_BIT	SBIT_PWMENA1  //The PWM1.1 output enabled

#define RIGHTMOTOR_ENABLE()			(LPC_GPIO2->FIOCLR = (0x1<<RIGHTMOTOR_ENABLE_BIT))
#define RIGHTMOTOR_DISABLE()		(LPC_GPIO2->FIOSET = (0x1<<RIGHTMOTOR_ENABLE_BIT))

#define RIGHTMOTOR_BREAK_ENABLE()	(LPC_GPIO2->FIOSET = (0x1<<RIGHTMOTOR_BREAK_BIT))
#define RIGHTMOTOR_BREAK_DISABLE()	(LPC_GPIO2->FIOCLR = (0x1<<RIGHTMOTOR_BREAK_BIT))

#define RIGHTMOTOR_DIR_FORWARD()	(LPC_GPIO2->FIOSET = (0x1<<RIGHTMOTOR_DIR_BIT))
#define RIGHTMOTOR_DIR_REVERSE()	(LPC_GPIO2->FIOCLR = (0x1<<RIGHTMOTOR_DIR_BIT))

#define RIGHTMOTOR_PWM_ENABLE()		(LPC_PWM1->PCR |= ((1<<RIGHTMOTOR_PWM_ENABLE_BIT)))
#define RIGHTMOTOR_PWM_DISABLE()	(LPC_PWM1->PCR &= ~((1<<RIGHTMOTOR_PWM_ENABLE_BIT)))


/********************************** Motor 1 Control Definitions ****************************************/

#define LEFTMOTOR_ENABLE_BIT 		21
#define LEFTMOTOR_BREAK_BIT 		22
#define LEFTMOTOR_DIR_BIT 			27
#define LEFTMOTOR_HALLIN_BIT 		28
#define LEFTMOTOR_PWM_ENABLE_BIT	SBIT_PWMENA2 // The PWM1.2 output enabled

#define LEFTMOTOR_ENABLE()			(LPC_GPIO0->FIOCLR = (0x1<<LEFTMOTOR_ENABLE_BIT))
#define LEFTMOTOR_DISABLE()		(LPC_GPIO0->FIOSET = (0x1<<LEFTMOTOR_ENABLE_BIT))

#define LEFTMOTOR_BREAK_ENABLE()	(LPC_GPIO0->FIOSET = (0x1<<LEFTMOTOR_BREAK_BIT))
#define LEFTMOTOR_BREAK_DISABLE()	(LPC_GPIO0->FIOCLR = (0x1<<LEFTMOTOR_BREAK_BIT))

#define LEFTMOTOR_DIR_REVERSE()	(LPC_GPIO0->FIOSET = (0x1<<LEFTMOTOR_DIR_BIT))
#define LEFTMOTOR_DIR_FORWARD()	(LPC_GPIO0->FIOCLR = (0x1<<LEFTMOTOR_DIR_BIT))

#define LEFTMOTOR_PWM_ENABLE()		(LPC_PWM1->PCR |= (1<<LEFTMOTOR_PWM_ENABLE_BIT)) 			//(The PWM6 output enabled)
#define LEFTMOTOR_PWM_DISABLE()	(LPC_PWM1->PCR &= ~(1<<LEFTMOTOR_PWM_ENABLE_BIT))			//(The PWM6 output disabled)

typedef struct
{
	float SEN_Angular_angle;
	float SEN_direction_Angle;
} SEN_STRUCT ;


typedef struct
{
	bool	MOT_Rotation_direction;
	int  	MOT_RPM;
} MOT_STRUCT ;

typedef struct
{

} MOD_STRUCT;


void unifiedContolBLDC(uint8_t leftWheel, uint8_t rightWheel);
void unifiedMotorInit();
void unifiedMotorPinsInit();
void unifiedPWMpinsInit();
void unifiedStop ();
void AGVStop();
void AGVRightTurn(uint8_t leftWheel, uint8_t rightWheel);
void AGVLeftTurn(uint8_t leftWheel, uint8_t rightWheel);
void AGVDirectionForward ();
void scaleSpeedsToThreshold (uint8_t* leftWheel, uint8_t* rightWheel);
bool isSharpTurn(uint8_t leftWheel, uint8_t rightWheel);
void reverseMotorDirectionBLDC ();
void AGVGoBackward (uint8_t leftWheel, uint8_t rightWheel);
void AGVStraightForward (uint8_t leftWheel, uint8_t rightWheel);



#endif /* MOTOR_H_ */
