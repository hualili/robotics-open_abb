/**
 * @file 				main.c
 * author: Arvind Allawadi
 * Date Modified: 11/07/2017
 *
 * Modified By: Tengxin Li
 * Date Modified: 07/05/2018
 *
 * Modified Note:
 * Remove all modbus related function call, add motor_handler as the thread entry
 *
 *-----------------------------------------------------------------------------------------------------------------
 *
	Conditions handled:
 * 1. Check if AGV is going forward or backwards: if forward ignore the signals from backwards and vice-versa
 * 2. Special condition: STOP -- After pressing STOP -- AGV can go either forward direction or backwards direction
 * 3. AGV can't start with the speed-up or speed-down button (buttons E and F)
 * 4. Speed-down should not STOP the AGV but reduce the speed to as low as 5.
 *
 * Other features included:
 * AGV should speed up by 20% and speed down by 10% on turns -- solves the issue of wider turns
 * Speed-up and Speed-down speed functionality to increase the speed upto 50 and reduce the speed as low as
 *
 *
 * */

/* ----------------------- System includes --------------------------------*/

/* ----------------------- Modbus includes ----------------------------------*/
//#include "timer.h"
//#include "string.h"
#include "../inc/motor_handler.h"

#include "stdbool.h"
#include <FreeRTOS.h>
#include <queue.h>

#include "../inc/defines.h"
#include "../inc/LoRa.h"

// HL, ZX, Apr 27, make head file, WHLMOTconf.h
#define MST							8    //Micro Steps            HL, ZX 4_26
#define Reduction_Ratio				35   //                       HL, ZX 4_26
#define Full_revo_steps				200  //                       HL, ZX 4_26
#define RADWHL						8    //radius for the wheel   HL, ZX 4_26
#define WIDVHL						1.067 // width of the vehicle HL, ZX 4_26
#define pi							3.1415926// 				  HL, ZX 4_27
#define inch_to_mm  				25.4 //					      HL, ZX 4_27
#define delta_t						10 // m-second			      HL, ZX 4_27
#define distance_required			1000 //mm, equals to 27 inch  HL, ZX 4_27
#define speed_slope_test			38.735 //					  HL, ZX 4_27
#define constant_number				266.7 //based on the eqn	  HL, ZX 4_27
#define MILDIS						38 //mm per million pulses    HL, ZX 4_30
#define MILMST						1000000 // For MST = 1/8	  HL, ZX 4_30
#define delta_num_pulse				6885246 //					  HL, ZX 4_30
#define duty_cyc					0.15 //						  HL, ZX 4_30
#define k_cal						88.26 // calibration coef	  HL, ZX 5_1
#define straight_distance			650 	//					  HL, ZX 5_3
#define stop_time					36000000 //					  HL, ZX 5_3

#define RF_Receive 					1
#define TransmittACk 				0
#define ack_start_stop 				0

char receiveData = 0;
int packetSize;

static volatile bool trueStart = false, isGoingBackwards = false, isGoingForwards = false;

volatile int test = 10;
//index to iterate the previous value buffer
//static uint8_t pIDX = 0;
//static uint8_t current_speed = 10;

//speed shift feature to increment/decrement the speed on each button pressed of Joystick
#define SPEED_SHIFT			5
static volatile bool emergencyStop = false;

static uint16_t cltd_turn_lvl = 0;

xQueueHandle xQueue;

typedef struct wheelsToScale {
	uint8_t leftWheel;
	uint8_t rightWheel;
};

//Declare speed_level
enum speed_level speed_lvl = SPD_LVL_IGNORE;

//Declare turn_level
enum turn_level turn_lvl = TRN_LVL_IGNORE;


static uint8_t counter;
struct Motor_data_frame data_frame;

struct wheelsToScale wheelScale;

void motor_data_frame_init() {
	memset(&data_frame, 0, sizeof(data_frame));
	//uint16_t i = 0;
	// The receive call will keep blocking if no data
	//xQueueReceive(xQueue, (void *) &data_frame, portMAX_DELAY);
	//vTaskDelay(1000);
	char temp[10] = "";
	if(xQueueReceive(xQueue,  &temp, portMAX_DELAY)){

		int i=0;
		//printf("number data: %c \n", temp[i]);
		data_frame.x_direction = (uint16_t)temp[i++] - 48;
		data_frame.y_direction = (uint16_t)temp[i++] - 48;
		data_frame.turn_first_byte = (uint16_t)temp[i++] - 48;
		data_frame.turn_second_byte = (uint16_t)temp[i++] - 48;
		data_frame.sign_action = (uint16_t)temp[i++] - 48;
		data_frame.speed_first_byte = (uint16_t)temp[i++] - 48;
		data_frame.speed_second_byte = (uint16_t)temp[i++] - 48;
		data_frame.first_delimiter = (uint16_t) temp[i++];
		data_frame.second_delimiter = (uint16_t)temp[i++];
		data_frame.third_delimiter = (uint16_t)temp[i++];

		//printf("***********************************next array*****************************************\n");
	}
}

//Scaling the duty cycle as per the PWM frequency requirement
//NOTE: The duty cycle will change based on the PWM frequency chosen.
//PWM frequency range for the AGV's BLDC controllers is 2KHz - 12 kHz
//NOT REQUIRED YET IN THIS PROJECT
void scaleDutyCycle(uint8_t speed) {
	uint8_t leftWheel = (speed >> 4) & 0x0F;
	uint8_t rightWheel = (speed & 0x0F);
	wheelScale.leftWheel = leftWheel < 5 ? leftWheel * 10 : leftWheel;
	wheelScale.rightWheel = rightWheel < 5 ? rightWheel * 10 : rightWheel;
}


void scaleMotorWheels(uint8_t speed) { // come back Apr 30

	wheelScale.leftWheel = speed;
	wheelScale.rightWheel = speed;

	uint8_t downSpeed = speed - speed / 10;
	uint8_t upSpeed = speed + speed / 10;

	switch (speed_lvl) {
	//	10% reduce 10% up

	//		RIGHT NOW LEVEL 2 IS SAME AS LEVEL 1
	case 0:
	case 1:
		switch (cltd_turn_lvl) {

		case 1:
			downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 10);
			upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 10);
			break;
		case 2:
			downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 10);
			upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 20);
			break;
		case 3:
			downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 20);
			upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 20);
			break;
		case 4:
			downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 20);
			upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 30);
			break;
		case 5:
			downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 30);
			upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 30);
			break;
		case 6:
			downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 30);
			upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 40);
			break;
		case 7:
			downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 40);
			upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 40);
			break;
		case 8:
			downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 40);
			upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 50);
			break;
		case 9:
			downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 65);
			upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 20);
			break;
		default:
			//			don't change the speed for case: ignore
			break;
		} //end switch
		//		break case
		break;

		case 2:
			switch (cltd_turn_lvl) {
			case 1:
				downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 3);
				upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 3);
				break;

			case 2:
				downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 3);
				upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 5);
				break;

			case 3:
				downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 5);
				upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 5);
				break;
			case 4:
				downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 5);
				upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 7);
				break;
			case 5:
				downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 7);
				upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 7);
				break;
			case 6:
				downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 7);
				upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 9);
				break;
			case 7:
				downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 9);
				upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 9);
				break;
			case 8:
				downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 9);
				upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 11);
				break;
			case 9:
				downSpeed = REDUCED_SPEED_FROM_PERCENTAGE(speed, 11);
				upSpeed = INCREASED_SPEED_FROM_PERCENTAGE(speed, 11);
				break;
			default:
				//			don't change the speed for case: ignore
				break;
			}
			break;

	}
	if (data_frame.sign_action == TURN_LEFT || data_frame.sign_action == Parking_turn_left) {
		wheelScale.leftWheel = downSpeed;
		wheelScale.rightWheel = upSpeed;
	} else if (data_frame.sign_action == TURN_RIGHT || data_frame.sign_action == Parking_turn_right) {
		wheelScale.leftWheel = upSpeed;
		wheelScale.rightWheel = downSpeed;
	}

	else {
		//			don't scale wheels' speed
	}

}

uint16_t calculate_speed() {
	uint16_t speed;
	switch (speed_lvl) { // all for duty cycles, f=2k HZ
	case 0:
		if (data_frame.speed_second_byte == 0)
			return speed = 10;
		if (data_frame.speed_second_byte == 1)
			return speed = 15;
		if (data_frame.speed_second_byte == 2)
			return speed = 20;
		break;
	case 1:
		if (data_frame.speed_second_byte == 0)
			return speed = 25;
		if (data_frame.speed_second_byte == 1)
			return speed = 30;
		if (data_frame.speed_second_byte == 2)
			return speed = 35;
		break;
	case 2:
		if (data_frame.speed_second_byte == 0)
			return speed = 40;
		if (data_frame.speed_second_byte == 1)
			return speed = 45;
		if (data_frame.speed_second_byte == 2)
			return speed = 50;
		break;
	default:
		//		we got ignore byte; make speed zero
		return speed = 0;
	}
}

//This function returns value between 1-9 inclusive which helps in checking the turn level
uint8_t calculate_turn() {
	uint8_t cal_turn_level;
	switch (turn_lvl) {
	case 0:
		if (data_frame.turn_second_byte == 0)
			return cal_turn_level = 1;
		if (data_frame.turn_second_byte == 1)
			return cal_turn_level = 2;
		if (data_frame.turn_second_byte == 2)
			return cal_turn_level = 3;
		break;
	case 1:
		if (data_frame.turn_second_byte == 0)
			return cal_turn_level = 4;
		if (data_frame.turn_second_byte == 1)
			return cal_turn_level = 5;
		if (data_frame.turn_second_byte == 2)
			return cal_turn_level = 6;
		break;
	case 2:
		if (data_frame.turn_second_byte == 0)
			return cal_turn_level = 7;
		if (data_frame.turn_second_byte == 1)
			return cal_turn_level = 8;
		if (data_frame.turn_second_byte == 2)
			return cal_turn_level = 9;
		break;
		//		set level to 99 indicating we have to ignore level
	case 99:
	default:
		return cal_turn_level = 99;
	}
	return -1;
}


void processReceivedframe() {

	//	initialize the motor_data_frame
	motor_data_frame_init();

	//	initialize levels from the frame
	speed_lvl = data_frame.speed_first_byte;
	turn_lvl = data_frame.turn_first_byte;

	/*
//	frame initialization failed
	if (frame_init != 1)
		return;
	 */

	// Tengxin 07/05: logic && or ||?
	//	frame integrity check
	if (data_frame.first_delimiter != 0x2A
			&& data_frame.second_delimiter != 0x2A
			&& data_frame.third_delimiter != 0x2A)
		return;

	uint16_t control_byte;
	uint16_t leftWheel, rightWheel;     // HL, change to leftDuty, rightDuty   Apr 30
	uint16_t cltd_speed;			// HL, change to cltdDuty    Apr 30

	//	calculate the duty cycle
	cltd_speed = calculate_speed();

	//	calculate the turn level from 1 to 9
	cltd_turn_lvl = calculate_turn();

	scaleMotorWheels(cltd_speed);  // all for duty cycles

	//	After scaling the wheels get the left wheel and the right wheel

	leftWheel = wheelScale.leftWheel;
	rightWheel = wheelScale.rightWheel;

	//get the control byte
	control_byte = data_frame.sign_action;
	/*HL Apr 30th, we need to add interactive instruction checking
	from TX2SVR to avoid blind turning
	 */

	//***convert to switch case KWL 032918 below
	switch (control_byte) {
	//if control byte is Stop do not process further-- stop the AGV
	case STOP:
		AGVStop();
		break;
		//turning straight right
	case TURN_RIGHT:
		AGVRightTurn(leftWheel, rightWheel);
		break;
		//turning left
	case TURN_LEFT:
		AGVLeftTurn(leftWheel, rightWheel);
		break;
		//going straight forward
	case SPEED_LIMIT_40:
		AGVStraightForward(leftWheel, rightWheel);
		break;

	case Parking_turn_left:
		AGVLeftTurn(leftWheel, rightWheel);
		/*
		int count_number=0;
		// calculate time for entering parking

		double deg_step, distance_step;
		deg_step = 360/Full_rev_steps;
		// distance per step = 360degree/Full_rev_steps * (1/Micro_steps) * (1/Reduction_Ratio) * (2*pi*Radius/360) * 0.0254 m/inch
		distance_step = deg_step / MST / Reduction_Ratio / 360 *( 2 * 3.1416 * RADWHL) * 0.0254;   //distance per step in meter
		count_number = 1.414 * WIDVHL / distance_step /(leftWheel/100);


		for(int i=0; i<count_number;++i);
//		control_byte = 4;   //speed_limit_40
		AGVStraightForward(cltd_speed, cltd_speed);
//		for(int i=0; i<50000000;++i);
//		puts("turn left\n");

		 */
		break;


	case Parking_turn_right:
		//		AGVStop();
		//		for(int i=0; i<delta_num_pulse;++i);   //for testing to mark the starting point
		AGVStraightForward(15, 15);

		/********************PARKING DISTANCE ABOVE***********************************
		int count_number, count_number_straight;
//		AGVRightTurn(leftWheel, rightWheel);
//		for(int i=0; i<27000000;++i);
		// calculate time for entering parking
		float distance_step, s_slop;
		// distance per step = 360degree/Full_rev_steps * (1/Micro_steps) * (1/Reduction_Ratio) * (2*pi*Radius/360) * 25.4 mm/inch
		distance_step = ( 2 * pi * RADWHL) /Full_revo_steps  / MST;
		s_slop =  distance_step * inch_to_mm / Reduction_Ratio * duty_cyc/k_cal;
		count_number = (distance_required)/s_slop + delta_num_pulse;
		count_number_straight = (straight_distance)/s_slop + delta_num_pulse;
		//calibration equation
//		count_number = (distance_required)/speed_slope_test * MILMST + delta_num_pulse;
//		for(int i=0; i<count_number;++i);
		//***********************PARKING DISTANCE ABOVE***********************************/

		int count_number=45494256;
		int count_number_straight=45494256;

		int count_enterexit=count_number-delta_num_pulse;
		AGVRightTurn(15, 1);
		for(int i=0; i<count_enterexit;++i);
		AGVLeftTurn(1,15);
		for(int i=0; i<count_number;++i);
		AGVStraightForward(15,15);
		for(int i=0; i<count_number_straight;++i);
		AGVStop();
		for(int i=0; i<stop_time;++i);  // testing, for stop
		AGVLeftTurn(1,15);
		for(int i=0; i<count_number;++i);
		AGVRightTurn(15, 1);
		for(int i=0; i<count_enterexit;++i);
		//		AGVStop();
		//		for(int i=0; i<50000000;++i);
		break;

	default:
		//we got ignore byte;
		break;
	}

	return;
}


//This functions checks if there is any data sent from the RF controller
void motor_handler(void *pvParameters) {
	xQueue = *(xQueueHandle *) pvParameters;

	for( ;; ) {
		processReceivedframe();
		vTaskDelay(1);//sleep for 1ms
	}
}

