/*
 * motor.c
 *
 *  Created on: Oct 15, 2016
 *      Author: Bharat
 */

/*
 ===============================================================================
 Name        : motor.c
 Author      : Arvind
 Description : PWM code for LPC1769
 ===============================================================================
 */

#include <stdio.h>
#include <assert.h>
#include "../inc/motor.h"
#include "../inc/defines.h"



// HL, ZX, Apr 27, make head file, WHLMOTconf.h
#define MST							8    //Micro Steps            HL, ZX 4_26
#define Reduction_Ratio				35   //                       HL, ZX 4_26
#define Full_revo_steps				200  //                       HL, ZX 4_26
#define RADWHL						8    //radius for the wheel   HL, ZX 4_26
#define WIDVHL						1.067 // width of the vehicle HL, ZX 4_26
#define pi							3.1415926// 				  HL, ZX 4_27
#define inch_to_mm  				25.4 //					      HL, ZX 4_27
#define delta_t						10 // m-second			      HL, ZX 4_27
#define distance_required			1000 //mm, equals to 27 inch  HL, ZX 4_27
#define speed_slope_test			38.735 //					  HL, ZX 4_27
#define constant_number				266.7 //based on the eqn	  HL, ZX 4_27
#define MILDIS						38 //mm per million pulses    HL, ZX 4_30
#define MILMST						1000000 // For MST = 1/8	  HL, ZX 4_30
#define delta_num_pulse				6885246 //					  HL, ZX 4_30
#define duty_cyc					0.15 //						  HL, ZX 4_30
#define k_cal						88.26 // calibration coef	  HL, ZX 5_1
#define straight_distance			1500 	//					  HL, ZX 5_3
#define stop_time					36000000 //					  HL, ZX 5_3


/**************************************************************************************************
 * @brief 	Initialize Motor0 PINS
 **************************************************************************************************/

/**************************************************************************************************
 * @brief	 	set duty cycle of PWM for Motor 2 according to given percentage value
 * @param[in]	dutyCycle	Duty-cycle in % value(valid values 1 to 100)
 * @return 		None
 **************************************************************************************************/

void unifiedMotorPinsInit() { // Set P2.1 as GPIO for Motor Enable
	LPC_PINCON->PINSEL4 &= ~(3 << 2);
	// Set P2.1 as output
	LPC_GPIO2->FIODIR |= (1 << RIGHTMOTOR_ENABLE_BIT);
	RIGHTMOTOR_DISABLE();

	// Set P2.2 as GPIO for Break
	LPC_PINCON->PINSEL4 &= ~(3 << 4);
	// Set P2.2 as output
	LPC_GPIO2->FIODIR |= (1 << RIGHTMOTOR_BREAK_BIT);
	// Set initial Value of P2.2 as 0 (No Brakes)
	LPC_GPIO2->FIOSET &= ~(0x1 << RIGHTMOTOR_BREAK_BIT);

	// Set P2.3 as GPIO for Direction
	LPC_PINCON->PINSEL4 &= ~(3 << 6);
	// Set P2.3 as output
	LPC_GPIO2->FIODIR |= (1 << RIGHTMOTOR_DIR_BIT);
	// Set initial Value of P2.3 as 1 (Forward Direction)
	LPC_GPIO2->FIOCLR |= (0x1 << RIGHTMOTOR_DIR_BIT);

	// Set P2.4 as GPIO for Hall Input
	LPC_PINCON->PINSEL4 &= ~(3 << 8);
	// Set P2.4 as input
	LPC_GPIO2->FIODIR &= ~(1 << RIGHTMOTOR_HALLIN_BIT);

	// Set P2.6 as output
	LPC_GPIO0->FIODIR |= (1 << LEFTMOTOR_ENABLE_BIT);
	LEFTMOTOR_DISABLE();

	// Set P2.7 as GPIO for Break
	LPC_PINCON->PINSEL1 &= ~(3 << 14);
	// Set P2.7 as output
	LPC_GPIO0->FIODIR |= (1 << LEFTMOTOR_BREAK_BIT);
	// Set initial Value of P2.7 as 0 (No Brakes)
	LPC_GPIO0->FIOSET &= ~(0x1 << LEFTMOTOR_BREAK_BIT);

	// Set P2.8 as GPIO for Direction
	LPC_PINCON->PINSEL1 &= ~(3 << 16);
	// Set P2.8 as output
	LPC_GPIO0->FIODIR |= (1 << LEFTMOTOR_DIR_BIT);
	// Set initial Value of P2.8 as 1 (Forward Direction)
	LPC_GPIO0->FIOSET |= (0x1 << LEFTMOTOR_DIR_BIT);

	// Set P2.10 as GPIO for Hall Input
	LPC_PINCON->PINSEL1 &= ~(3 << 20);
	// Set P2.10 as input
	LPC_GPIO0->FIODIR &= ~(1 << LEFTMOTOR_HALLIN_BIT);

	//Step: Direction of the wheel should be FORWARD
	AGVDirectionForward();

}

void AGVRightTurn(uint8_t leftWheel, uint8_t rightWheel) {
	assert(leftWheel > rightWheel);

	//For simplicity -- Assumption this function is for Forward Right Turn
	AGVDirectionForward();
	if (isSharpTurn(leftWheel, rightWheel))
			scaleSpeedsToThreshold(&leftWheel, &rightWheel);
	unifiedContolBLDC(leftWheel, rightWheel);
}

//Function to control the sharpness of the turn -- Scale as per the AGV
bool isSharpTurn(uint8_t leftWheel, uint8_t rightWheel) {
	return ((abs(leftWheel - rightWheel) > 50) || (leftWheel == 0)
			|| (rightWheel == 0));
}

void AGVLeftTurn(uint8_t leftWheel, uint8_t rightWheel) {

	assert(rightWheel > leftWheel);
	//For simplicity -- Assumption this function is for Forward Left Turn
	AGVDirectionForward();
	if (isSharpTurn(leftWheel, rightWheel))
		scaleSpeedsToThreshold(&leftWheel, &rightWheel);
	//isLeft stores the intensity of the turn

	//isLeft >=5 sharp turn
	unifiedContolBLDC(leftWheel, rightWheel);
}

/*
void motTurn(uint8_t WHL, uint8_t fpwmL, uint8_t fpwmR, int dutyL, int dutyR, int angle){
			int count_number, count_number_straight;
			float distance_step, s_slop;
			// distance per step = 360degree/Full_rev_steps * (1/Micro_steps) * (1/Reduction_Ratio) * (2*pi*Radius/360) * 25.4 mm/inch
			distance_step = ( 2 * pi * RADWHL) /Full_revo_steps  / MST;
			s_slop =  distance_step * inch_to_mm / Reduction_Ratio * duty_cyc/k_cal;
			count_number = (distance_required) / s_slop * angle / 90  + delta_num_pulse;

			switch(WHL){
			case 1:  //left turn
				AGVLeftTurn(dutyL,dutyR);
				for(int i=0; i<count_number;++i);
				break;

			case 2:  //right turn
				AGVRightTurn(dutyL,dutyR);
				for(int i=0; i<count_number;++i);
				break;

			case 3:  //straight forward
				AGVStraightForward(dutyL,dutyR);
				for(int i=0; i<count_number;++i);
				break;
			}


}

*/


void AGVDirectionForward() {
	RIGHTMOTOR_DIR_FORWARD();
	LEFTMOTOR_DIR_FORWARD();
}

void scaleSpeedsToThreshold(uint8_t* leftWheel, uint8_t* rightWheel) {

	if (*leftWheel == 0)
		*leftWheel = 10;
	else if (*rightWheel == 0)
		*rightWheel = 10;
	else if (*leftWheel - *rightWheel < 0) {
		//scale the rightwheel speed
		if (*leftWheel < 10)
			*leftWheel = 10;
	} else if (*rightWheel < 10)
		*rightWheel = 10;

}

void reverseMotorDirectionBLDC() {

	RIGHTMOTOR_DIR_REVERSE();
	LEFTMOTOR_DIR_REVERSE();
}
void AGVGoBackward(uint8_t leftWheel, uint8_t rightWheel) {

	//Step 1: reverse the direction of Motor pins
	reverseMotorDirectionBLDC();
	if (isSharpTurn(leftWheel, rightWheel))
		scaleSpeedsToThreshold(leftWheel, rightWheel);
	unifiedContolBLDC(leftWheel, rightWheel);
}

void AGVStraightForward (uint8_t leftWheel, uint8_t rightWheel) {
	assert (leftWheel == rightWheel);
	AGVDirectionForward();
	unifiedContolBLDC(leftWheel, rightWheel);
}

void unifiedPWMpinsInit() {
	LPC_SC->PCONP |= (1 << 6);
	LPC_SC->PCLKSEL0 |= (3 << 12);  // set 12 and set 13

	// P2.0 -> PWM1.1
	LPC_PINCON->PINSEL4 &= ~(3 << 0);
	LPC_PINCON->PINSEL4 |= (1 << 0);

	// P2.1 -> PWM1.2
	LPC_PINCON->PINSEL4 &= ~(3 << 2);
	LPC_PINCON->PINSEL4 |= (1 << 2);

	//NO PR setting required
	LPC_PWM1->PR = 0x00;
	LPC_PWM1->MCR = (1 << 1);
	// See calculation below
	LPC_PWM1->MR0 = 6250; //2kHz frequency
	LPC_PWM1->MR1 = 1000;
	LPC_PWM1->MR2 = 1000;
	LPC_PWM1->LER |= ((1 << 0) | (1 << 1));
	LPC_PWM1->PCR |= ((1 << 9) | (1 << 10));      //Enable PWM1 Channel 2 output
	LPC_PWM1->TCR |= ((1 << 0) | (1 << 3));
}

/**************************************************************************************************
 * motorInit : Motor Initialize
 **************************************************************************************************/

void unifiedMotorInit() {
	unifiedMotorPinsInit();
	unifiedPWMpinsInit();
}

void unifiedContolBLDC(uint8_t leftWheel, uint8_t rightWheel) {

	//Step 1: make sure Motors pins are enabled
	RIGHTMOTOR_ENABLE();
	LEFTMOTOR_ENABLE();

	uint32_t temp = 0, newLeftValue = 0, newRightValue = 0;

//		LPC_PWM1->MCR = (1 << 1); //Match control register, TC reset if MR0 matches it
	temp = LPC_PWM1->MR0;
//		LPC_PWM1->TCR = 2;        //Reset the counter, TCR used for disable/reset TC
	if (leftWheel >= 0 && leftWheel <= 100)
		newLeftValue = (uint32_t) (temp * leftWheel) / 100;

	if (rightWheel >= 0 && rightWheel <= 100)
		newRightValue = (uint32_t) (temp * rightWheel) / 100;

	//PCR, TCR are initialized in motor initialization function
//		LPC_PWM1->PCR |= ((1 << 9) | (1 << 10) );                 //Enable PWM1 Channel 2 output
//		LPC_PWM1->TCR |= ((1 << 0) | (1 << 3));
	LPC_PWM1->MR2 = newLeftValue; // channel 2 is the left tire
	LPC_PWM1->MR1 = newRightValue; // channel 1 is the right tire
	LPC_PWM1->LER |= ((1 << 0) | (1 << 1) | (1 << 2));

}

void AGVStop() {
	unifiedStop();
}
void unifiedStop() {
//PCR, TCR are initialized in motor initialization function
//	LPC_PWM1->PCR |= ((1 << 10) | (1 << 9));         //Enable PWM1 Channel 2 output
//	LPC_PWM1->TCR |= ((1 << 0) | (1 << 3));

	//Logic: Lower the speed to lowest and enable the Motor's break bit (pin) -- Implemented
	LPC_PWM1->MR1 = 4; //Gradual Stop
	LPC_PWM1->MR2 = 4; //Gradual Stop
	LPC_PWM1->LER |= ((1 << 0) | (1 << 1) | (1 << 2)); //latch MR0 & MR1
	RIGHTMOTOR_BREAK_ENABLE(); //TO fully stop the AGV
	LEFTMOTOR_BREAK_ENABLE(); //To fully stop the AGV
}

