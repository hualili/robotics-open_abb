Open Terminal and run:
    python3 Test-Dual-Camera.py
