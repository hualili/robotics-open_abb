'''-------------------------------------------------------------------------
* Company Name : CTI One Corp;                                             *
* Program name : TestObjectTracker.py                                          *
* Coded By     : Minh Duc Ong                                              *
* Date         : 5-30-2020                                                 *
* Version      : v0.01                                                     * 
* Copyright    : copyright (c) 2020 CTI One Corporation                    *
* Purpose      : to test the API of CAMSVR2 with DTU devices               *
-----------------------------------------------------------------------------'''
import numpy as np
import cv2
import argparse
import time
import os
import math
from datetime import datetime
from skimage.measure import compare_ssim
import time
import imutils
from matplotlib import pyplot as plt
from centroidtracker import CentroidTracker

from collections import deque
from array import *
# initialize our centroid tracker and frame dimensions
ct = CentroidTracker()
im_0 = None
im_1 = None
cv2.namedWindow ('Image 0', cv2.WINDOW_NORMAL)
cv2.namedWindow ('Image 1', cv2.WINDOW_NORMAL)
for i in range (2):
    print('image num: ',i)
    im = cv2.imread('img'+str(i)+'.jpg')
    imgray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    ret, thresh = cv2.threshold(imgray, 127, 255, 0)
    _, contours, hierarchy = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    img = np.zeros(im.shape, np.uint8)
    cv2.drawContours(im, contours, -1, (0,255,0), 3)
    rects = []
    for c in contours:
        #print ('c',c)
        (x,y,w,h) = cv2.boundingRect(c)
        box = (x, y, x+w, y+h)* np.array([1, 1, 1, 1])
        rects.append(box.astype("int"))
    objects = ct.update(rects)
    # loop over the tracked objects
    for (objectID, centroid) in objects.items():
        # draw both the ID of the object and the centroid of the
        # object on the output frame
        text = "ID {}".format(objectID)
        cv2.putText(im, text, (centroid[0] - 10, centroid[1] - 10),
            cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 0), 2)
        x =  centroid[0] - 25
        y =  centroid[1] - 25
        cv2.putText(im, '(' + str(x)+ ', ' +str(y) + ')', (centroid[0] + 120, centroid[1] - 10),
            cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 0), 2)
        print ('objectID ' + ' (x_bar, y_bar): ' + str(objectID) + ' ('+ str((x,y)) + ')')
        cv2.circle(im, (centroid[0], centroid[1]), 4, (0, 255, 0), -1)
    #cv2.imshow('contour', im)
    if i == 0:
        im_0 = im
    if i == 1:
        im_1 = im
    print('\n') 
    #cv2.waitKey(2000)
cv2.imshow ('Image 0', im_0)
cv2.imshow ('Image 1', im_1)
cv2.waitKey(0)
