import numpy as np
import cv2 as cv
# Create a black image
img = np.zeros((1080,1920,3), np.uint8)
# Draw a diagonal blue line with thickness of 5 px
cv.rectangle(img,(1000,200),(1050,250),(255,255,255),-1)
cv.rectangle(img,(500,350),(550,400),(255,255,255),-1)
cv.rectangle(img,(1200,600),(1250,650),(255,255,255),-1)
cv.imwrite('img2.jpg',img)
