
def xor(a, b): 
	result = [] 
	for i in range(1, len(b)): 
		if a[i] == b[i]: 
			result.append('0') 
		else: 
			result.append('1') 

	return ''.join(result) 

def mod2div(divident, divisor): 
	pick = len(divisor) 
	tmp = divident[0 : pick] 

	while pick < len(divident): 

		if tmp[0] == '1': 
			tmp = xor(divisor, tmp) + divident[pick] 

		else: # If leftmost bit is '0' 
			tmp = xor('0'*pick, tmp) + divident[pick] 
		pick += 1
	if tmp[0] == '1': 
		tmp = xor(divisor, tmp) 
	else: 
		tmp = xor('0'*pick, tmp) 

	checkword = tmp 
	return checkword 

def decodeData(data, key): 

	l_key = len(key) 
	appended_data = data + '0'*(l_key-1) 
	remainder = mod2div(appended_data, key) 

	return remainder 

# Defining BinarytoDecimal() function 
def BinaryToDecimal(binary): 
		
	binary1 = binary 
	decimal, i, n = 0, 0, 0
	while(binary != 0): 
		dec = binary % 10
		decimal = decimal + dec * pow(2, i) 
		binary = binary//10
		i += 1
	return (decimal)

data =input("receieved data in binary  ")
#print (data) 
key = "1001"
ans = decodeData(data, key) 
print("Remainder after decoding is->"+ans) 
	
temp = "0" * (len(key) - 1) 
if ans == temp: 
    print("no error")
    #decode message # convert binary data to string
    #remove last 4 bits
    in_data = data
    l=len(in_data)
    bin_data=in_data[0:l-3]
    #print(bin_data)
    # bin_data is received msg - crc code
    
    #convert bin_data to string
    str_data =' '

    # slicing the input and converting it 
    # in decimal and then converting it in string 
    for i in range(0, len(bin_data), 8): 
	
            # slicing the bin_data from index range [0, 6] 
            # and storing it as integer in temp_data 
            temp_data = int(bin_data[i:i + 8]) 
            
            # passing temp_data in BinarytoDecimal() fuction 
            # to get decimal value of corresponding temp_data 
            decimal_data = BinaryToDecimal(temp_data) 
            
            # Deccoding the decimal value returned by 
            # BinarytoDecimal() function, using chr() 
            # function which return the string corresponding 
            # character for given ASCII value, and store it 
            # in str_data 
            str_data = str_data + chr(decimal_data) 

    # printing the result 
    print("The original message is -> ", str_data) 

    
else: 
    print("error in received message")
        
	
