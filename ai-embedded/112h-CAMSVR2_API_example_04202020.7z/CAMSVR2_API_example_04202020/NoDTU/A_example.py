'''-------------------------------------------------------------------------
* Company Name : CTI One Corp;                                             *
* Program name : A_example.py                                              *
* Coded By     : Minh Duc Ong                                              *
* Date         : 4-20-2020                                                 *
* Version      : v0.01                                                     * 
* Copyright    : copyright (c) 2020 CTI One Corporation                    *
* Purpose      : to test the API of CAMSVR2 without DTU devices            *
-----------------------------------------------------------------------------'''

import A_camsvr2_api as acamsvr2

# ----------------------------------Establish Connection---------------------------*
# createConnection: create connection to CAMSVR-2
# Args:
#        param1(string) : camera ID.
#        param2(string) : host ID
#        param3(int)    : port connection
#        param4(bool)   : parity checking True/False
connection, frame = acamsvr2.createConnection('N1000001', '/dev/ttyUSB0', 115200, 1) #HandShaking. 

# ----------------------------------Set ROI for Intrusion---------------------------*
# setROI: set Region of Interest (ROI)
# Args:
#        param1(socket) : connection
#        param2(x,y)    : first Point of ROI
#        param3(x,y)    : second Point of ROI
time.sleep(1)
acamsvr2.setROI(connection,(100,100),(150,200))


# ----------------------------------Set Threshold for Intrusion---------------------*
# Set Threshold (ROI)
# Args:
#        param1(socket) : connection
#        param2(int)    : threshold for Intrusion, 1-10, smaller value give more sensitive of the detection
#        param3(int)    : threshold for image binarization algorithm, 0-255
time.sleep(1)
acamsvr2.setIntrusion(connection,4,45) 

# ----------------------------------Enable/Disbale HeatBeat Signal---------------------*
# enHeartBeat: Enable/Disbale HeatBeat Signal
# Args:
#        param1(socket) : connection
#        param2(bool)   : enable/disable Heart Beat. True/False or 0/1
#        param3(int)    : the period (in second) 0->999
time.sleep(1)
acamsvr2.enHeartBeat(connection,1,10) 

# ----------------------------------RTC Sync--------------------------------------------*
# writeRTC: Synchronize RTC
# Args:
#        param1(socket) : connection
#        param2(string) : RTC Value: YYMMDDhhmmss 
time.sleep(1)
acamsvr2.writeRTC(connection,'200415071801') 
 
# ----------------------------------Get Video List---------------------------------------*
# getVideoList: get Video names on CAMSVR2
# Args:
#        param1(socket) : connection
time.sleep(1)
video_file_list = acamsvr2.getVideoList(connection) 
print("Video File List: ",video_file_list)

# ----------------------------------Delete Video------------------------------------------*
# delVideoFile: delete video file on CAMSVR2
# Args:
#        param1(socket) : connection
#        param2(string) : video name will be deleted
time.sleep(1)
#acamsvr2.delVideoFile(connection,"VQA-N1000001-20200415-120150.avi")

# ----------------------------------Delete Video------------------------------------------*
# getVideoFile: delete video file on CAMSVR2
# Args:
#        param1(socket) : connection
#        param2(string) : video name will be downloaded to local directory
time.sleep(1)
#acamsvr2.getVideoFile(connection,"VQA-N1000001-20200415-120135.avi")

heartbeat_message = ''

while (True):
     # ----------------------------------receive HeartBeat message-------------------------*
     # getHeartBeat: return heart beat message from CASMVR2, if message = ***YYY Intrusion happen, ***000 NO 
     # intrusion happen
     # Args:
     #   param1(socket) : connection
     time.sleep(1)
     heartbeat_message = acamsvr2.getHeartBeat(connection)

     print ("Hear Beat message:", heartbeat_message)

     if (heartbeat_message[:6] == '***YYY'): #condition to check Intrusion 
        # ----------------------------------receive Intrusion Image-------------------------*
        # getIntrusion: return current intrusion image
        # intrusion happen
        # Args:
        #  param1(socket) : connection
        #  param2(int)    : timeout
        time.sleep(1)
        intrusion_frame = acamsvr2.getIntrusion(connection ,1)
        cv2.imshow('frame',intrusion_frame)
        cv2.waitKey()

# ----------------------------------close Connection-------------------------*
# closeConnection: close connection to CAMSVR-2
# intrusion happen
# Args:
#        param1(socket) : connection need to be closed
acamsvr2.closeConnection(connection)
        




